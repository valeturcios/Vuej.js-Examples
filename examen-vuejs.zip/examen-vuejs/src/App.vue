<template>
  <div id="app" :class="{ dark: darkMode, light: !darkMode }">

    <header class="header">
      <h1>🚀 Examen Vue.js - 10 Ejercicios Prácticos</h1>
      <p>Universidad Luterana Salvadoreña - Ciencias de la Computación</p>
    </header>

    <main class="main-content">
      <div class="exercises-grid">
        <!-- Ejercicios Composition API -->
        <section class="api-section">
          <h2 class="api-title composition">
            <span class="api-badge composition">Composition API</span>
          </h2>
          
          <div class="exercise-card">
            <h3>1. Mensaje de Bienvenida</h3>
            <WelcomeMessage />
          </div>

          <div class="exercise-card">
            <h3>3. Mostrar/Ocultar Mensaje</h3>
            <ToggleMessage />
          </div>

          <div class="exercise-card">
            <h3>5. Lista de Tareas</h3>
            <TaskList />
          </div>

          <div class="exercise-card">
            <h3>6. Calculadora Sencilla</h3>
            <SimpleCalculator />
          </div>

          <div class="exercise-card">
          <h3>7. Toggle Tema Oscuro/Claro</h3>
          <ThemeToggle @theme-changed="setTheme" />
          </div>

          <div class="exercise-card">
            <h3>10. Watchers</h3>
            <WatcherExample />
          </div>
        </section>

        <!-- Ejercicios Options API -->
        <section class="api-section">
          <h2 class="api-title options">
            <span class="api-badge options">Options API</span>
          </h2>

          <div class="exercise-card">
            <h3>2. Contador de Clics</h3>
            <ClickCounter />
          </div>

          <div class="exercise-card">
            <h3>4. Manejar Eventos Input</h3>
            <InputHandler />
          </div>

          <div class="exercise-card">
            <h3>8. Renderizado Condicional</h3>
            <ConditionalRender />
          </div>

          <div class="exercise-card">
            <h3>9. Propiedades Computadas</h3>
            <ComputedProperties />
          </div>
        </section>
      </div>
    </main>

    <footer class="footer">
      <p>✨ Catedrático: Msc Jorge Alberto Coto Zelaya</p>
      <p>📚 Nuevas Tendencias de Programación - Ciclo II-2025</p>
    </footer>
  </div>
</template>

<script>
// Composition API Components
import WelcomeMessage from './components/CompositionAPI/WelcomeMessage.vue'
import ToggleMessage from './components/CompositionAPI/ToggleMessage.vue'
import TaskList from './components/CompositionAPI/TaskList.vue'
import SimpleCalculator from './components/CompositionAPI/SimpleCalculator.vue'
import ThemeToggle from './components/CompositionAPI/ThemeToggle.vue'
import WatcherExample from './components/CompositionAPI/WatcherExample.vue'

// Options API Components
import ClickCounter from './components/OptionsAPI/ClickCounter.vue'
import InputHandler from './components/OptionsAPI/InputHandler.vue'
import ConditionalRender from './components/OptionsAPI/ConditionalRender.vue'
import ComputedProperties from './components/OptionsAPI/ComputedProperties.vue'

export default {
  name: 'App',
  components: {
    WelcomeMessage,
    ToggleMessage,
    TaskList,
    SimpleCalculator,
    ThemeToggle,
    WatcherExample,
    ClickCounter,
    InputHandler,
    ConditionalRender,
    ComputedProperties
  },
  data() {
    return {
      darkMode: false
    }
  },
  methods: {
    setTheme(isDark) {
      this.darkMode = isDark
    }
  }
}
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
#app {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  min-height: 100vh;
  transition: background 0.5s ease, color 0.5s ease;
}

#app.light {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: black;
}

#app.dark {
  background: linear-gradient(135deg, #0f2027 0%, #2c5364 100%);
  color: white;
}

.header {
  text-align: center;
  padding: 2rem;
  color: white;
}
.exercise-card {
  background: white;
  color: black;
  transition: background 0.5s ease, color 0.5s ease;
}

#app.dark .exercise-card {
  background: #1e293b; /* gris oscuro */
  color: white;
}

.header h1 {
  font-size: 2.5rem;
  margin-bottom: 0.5rem;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.header p {
  font-size: 1.2rem;
  opacity: 0.9;
}

.main-content {
  padding: 0 2rem 2rem;
  max-width: 1400px;
  margin: 0 auto;
}

.exercises-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
}

.api-section {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 20px;
  padding: 2rem;
  box-shadow: 0 15px 35px rgba(0,0,0,0.1);
}

.api-title {
  text-align: center;
  margin-bottom: 2rem;
}

.api-badge {
  padding: 0.5rem 1.5rem;
  border-radius: 25px;
  font-size: 1.1rem;
  font-weight: bold;
  text-transform: uppercase;
  color: white;
}

.api-badge.composition {
  background: linear-gradient(45deg, #10b981, #059669);
}

.api-badge.options {
  background: linear-gradient(45deg, #f59e0b, #d97706);
}

.exercise-card {
  background: white;
  border-radius: 15px;
  padding: 1.5rem;
  margin-bottom: 1.5rem;
  box-shadow: 0 5px 15px rgba(0,0,0,0.08);
  border: 1px solid #e5e7eb;
  transition: all 0.3s ease;
}

.exercise-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}

.exercise-card h3 {
  color: #374151;
  margin-bottom: 1rem;
  font-size: 1.1rem;
  border-bottom: 2px solid #f3f4f6;
  padding-bottom: 0.5rem;
}

.footer {
  text-align: center;
  padding: 2rem;
  color: white;
  background: rgba(0,0,0,0.2);
}

.footer p {
  margin: 0.25rem 0;
  opacity: 0.9;
}

@media (max-width: 768px) {
  .exercises-grid {
    grid-template-columns: 1fr;
  }
  
  .header h1 {
    font-size: 2rem;
  }
  
  .main-content {
    padding: 0 1rem 1rem;
  }
}
</style>