<template>
  <div class="task-list-container">
    <!-- Formulario para agregar tareas -->
    <div class="add-task-section mb-4">
      <div class="input-group">
        <input 
          v-model="newTask" 
          @keyup.enter="addTask"
          class="input-field" 
          placeholder="Escribe una nueva tarea..."
          :disabled="tasks.length >= 10"
        />
        <button 
          @click="addTask" 
          class="btn btn-success"
          :disabled="!newTask.trim() || tasks.length >= 10"
        >
          ➕ Agregar
        </button>
      </div>
      
      <div v-if="tasks.length >= 10" class="message warning">
        ⚠️ Límite máximo de 10 tareas alcanzado
      </div>
    </div>

    <!-- Lista de tareas -->
    <div class="tasks-section">
      <div v-if="tasks.length === 0" class="empty-state">
        <div class="message info">
          <span class="empty-icon">📝</span>
          No hay tareas pendientes. ¡Agrega una nueva!
        </div>
      </div>

      <transition-group name="task" tag="div" class="task-list">
        <div 
          v-for="(task, index) in tasks" 
          :key="task.id" 
          class="task-item"
          :class="{ 'completed': task.completed }"
        >
          <div class="task-content">
            <input 
              type="checkbox" 
              v-model="task.completed" 
              class="task-checkbox"
            />
            <span class="task-text" :class="{ 'line-through': task.completed }">
              {{ task.text }}
            </span>
            <small class="task-time">{{ task.createdAt }}</small>
          </div>
          
          <div class="task-actions">
            <button 
              @click="editTask(index)" 
              class="btn-small btn-warning"
              :disabled="task.completed"
            >
              ✏️
            </button>
            <button 
              @click="removeTask(index)" 
              class="btn-small btn-danger"
            >
              🗑️
            </button>
          </div>
        </div>
      </transition-group>
    </div>

    <!-- Estadísticas -->
    <div v-if="tasks.length > 0" class="stats-section">
      <div class="stats-grid">
        <div class="stat-item">
          <span class="stat-number">{{ tasks.length }}</span>
          <span class="stat-label">Total</span>
        </div>
        <div class="stat-item">
          <span class="stat-number">{{ completedTasks }}</span>
          <span class="stat-label">Completadas</span>
        </div>
        <div class="stat-item">
          <span class="stat-number">{{ pendingTasks }}</span>
          <span class="stat-label">Pendientes</span>
        </div>
      </div>
      
      <div class="action-buttons">
        <button @click="clearCompleted" class="btn btn-warning" :disabled="completedTasks === 0">
          🧹 Limpiar Completadas
        </button>
        <button @click="clearAll" class="btn btn-danger">
          🗑️ Limpiar Todo
        </button>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed } from 'vue'

export default {
  name: 'TaskList',
  setup() {
    const tasks = ref([])
    const newTask = ref('')
    let taskIdCounter = 1

    // Computed properties
    const completedTasks = computed(() => 
      tasks.value.filter(task => task.completed).length
    )
    
    const pendingTasks = computed(() => 
      tasks.value.filter(task => !task.completed).length
    )

    // Methods
    const addTask = () => {
      if (newTask.value.trim() && tasks.value.length < 10) {
        tasks.value.push({
          id: taskIdCounter++,
          text: newTask.value.trim(),
          completed: false,
          createdAt: new Date().toLocaleTimeString()
        })
        newTask.value = ''
      }
    }

    const removeTask = (index) => {
      tasks.value.splice(index, 1)
    }

    const editTask = (index) => {
      const newText = prompt('Editar tarea:', tasks.value[index].text)
      if (newText && newText.trim()) {
        tasks.value[index].text = newText.trim()
      }
    }

    const clearCompleted = () => {
      tasks.value = tasks.value.filter(task => !task.completed)
    }

    const clearAll = () => {
      if (confirm('¿Estás seguro de que quieres eliminar todas las tareas?')) {
        tasks.value = []
        taskIdCounter = 1
      }
    }

    return {
      tasks,
      newTask,
      completedTasks,
      pendingTasks,
      addTask,
      removeTask,
      editTask,
      clearCompleted,
      clearAll
    }
  }
}
</script>

<style scoped>
.task-list-container {
  padding: 1rem;
}

.input-group {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}

.input-group .input-field {
  flex: 1;
}

.empty-state {
  text-align: center;
  padding: 2rem;
}

.empty-icon {
  font-size: 2rem;
  margin-right: 0.5rem;
}

.task-list {
  space: 0.5rem;
}

.task-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  background: #f9fafb;
  border-radius: 10px;
  margin-bottom: 0.5rem;
  border: 1px solid #e5e7eb;
  transition: all 0.3s ease;
}

.task-item:hover {
  background: #f3f4f6;
  border-color: #d1d5db;
}

.task-item.completed {
  opacity: 0.7;
  background: #f0f9ff;
}

.task-content {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex: 1;
}

.task-checkbox {
  width: 18px;
  height: 18px;
}

.task-text {
  flex: 1;
  font-weight: 500;
}

.task-text.line-through {
  text-decoration: line-through;
  color: #6b7280;
}

.task-time {
  color: #9ca3af;
  font-size: 0.8rem;
}

.task-actions {
  display: flex;
  gap: 0.5rem;
}

.btn-small {
  padding: 0.4rem 0.6rem;
  font-size: 0.8rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-small:hover {
  transform: scale(1.05);
}

.btn-small:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
}

.btn-warning {
  background: #f59e0b;
  color: white;
}

.btn-danger {
  background: #ef4444;
  color: white;
}

.stats-section {
  margin-top: 1.5rem;
  padding: 1rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 15px;
  color: white;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 1rem;
  margin-bottom: 1rem;
}

.stat-item {
  text-align: center;
}

.stat-number {
  display: block;
  font-size: 2rem;
  font-weight: bold;
  line-height: 1;
}

.stat-label {
  font-size: 0.85rem;
  opacity: 0.9;
}

.action-buttons {
  display: flex;
  gap: 0.5rem;
  justify-content: center;
}

.action-buttons .btn {
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.action-buttons .btn:hover {
  background: rgba(255, 255, 255, 0.3);
}

.task-enter-active, .task-leave-active {
  transition: all 0.4s ease;
}

.task-enter-from {
  opacity: 0;
  transform: translateX(-30px);
}

.task-leave-to {
  opacity: 0;
  transform: translateX(30px);
}

.task-move {
  transition: transform 0.4s ease;
}

@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: repeat(3, 1fr);
    gap: 0.5rem;
  }
  
  .stat-number {
    font-size: 1.5rem;
  }
  
  .action-buttons {
    flex-direction: column;
  }
}
</style>