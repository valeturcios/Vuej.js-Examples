<template>
  <div class="watcher-container">
    <div class="input-section">
      <div class="input-group">
        <label for="watched-input">🔍 Valor Observado:</label>
        <input 
          id="watched-input"
          v-model="watchedValue" 
          class="input-field" 
          placeholder="Escribe algo para ver los watchers en acción..."
        />
      </div>

      <div class="input-group">
        <label for="number-input">🔢 Número Observado:</label>
        <input 
          id="number-input"
          v-model.number="numberValue" 
          type="number" 
          class="input-field" 
          placeholder="Ingresa un número"
        />
      </div>
    </div>

    <!-- Messages Section -->
    <div class="messages-section">
      <transition name="fade">
        <div v-if="changeMessage" class="message info">
          <span class="message-icon">📝</span>
          <div class="message-content">
            <strong>Cambio de Texto Detectado:</strong>
            <div class="change-detail">{{ changeMessage }}</div>
          </div>
        </div>
      </transition>

      <transition name="fade">
        <div v-if="numberMessage" class="message success">
          <span class="message-icon">🔢</span>
          <div class="message-content">
            <strong>Cambio de Número:</strong>
            <div class="change-detail">{{ numberMessage }}</div>
          </div>
        </div>
      </transition>

      <transition name="fade">
        <div v-if="validationMessage" class="message" :class="validationClass">
          <span class="message-icon">{{ validationIcon }}</span>
          <div class="message-content">
            <strong>Validación:</strong>
            <div class="change-detail">{{ validationMessage }}</div>
          </div>
        </div>
      </transition>
    </div>

    <!-- Statistics Section -->
    <div class="stats-section">
      <h4>📊 Estadísticas de Cambios</h4>
      <div class="stats-grid">
        <div class="stat-card">
          <span class="stat-number">{{ textChanges }}</span>
          <span class="stat-label">Cambios de Texto</span>
        </div>
        <div class="stat-card">
          <span class="stat-number">{{ numberChanges }}</span>
          <span class="stat-label">Cambios Numéricos</span>
        </div>
        <div class="stat-card">
          <span class="stat-number">{{ totalChanges }}</span>
          <span class="stat-label">Total de Cambios</span>
        </div>
        <div class="stat-card">
          <span class="stat-number">{{ watchedValue.length }}</span>
          <span class="stat-label">Longitud Actual</span>
        </div>
      </div>
    </div>

    <!-- History Section -->
    <div v-if="changeHistory.length > 0" class="history-section">
      <h4>📈 Historial de Cambios</h4>
      <div class="history-list">
        <div 
          v-for="(change, index) in changeHistory.slice(-5)" 
          :key="index"
          class="history-item"
        >
          <div class="history-header">
            <span class="history-type" :class="change.type">{{ change.type.toUpperCase() }}</span>
            <span class="history-time">{{ change.timestamp }}</span>
          </div>
          <div class="history-content">
            <span class="history-from">"{{ change.from }}"</span>
            <span class="history-arrow">→</span>
            <span class="history-to">"{{ change.to }}"</span>
          </div>
        </div>
      </div>
      <button @click="clearHistory" class="btn btn-warning btn-small">
        🧹 Limpiar Historial
      </button>
    </div>

    <!-- Advanced Watchers Demo -->
    <div class="advanced-section">
      <h4>🔬 Watchers Avanzados</h4>
      <div class="advanced-content">
        <div class="watcher-info">
          <div class="watcher-item">
            <span class="watcher-label">Immediate Watcher:</span>
            <span class="watcher-status" :class="{ active: immediateTriggered }">
              {{ immediateTriggered ? '✅ Activado' : '⏳ Esperando' }}
            </span>
          </div>
          <div class="watcher-item">
            <span class="watcher-label">Deep Watcher:</span>
            <span class="watcher-status" :class="{ active: deepTriggered }">
              {{ deepTriggered ? '✅ Activado' : '⏳ Esperando' }}
            </span>
          </div>
          <div class="watcher-item">
            <span class="watcher-label">Debounced Watcher:</span>
            <span class="watcher-status" :class="{ active: debouncedTriggered }">
              {{ debouncedTriggered ? '✅ Activado' : '⏳ Esperando' }}
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, watch, watchEffect } from 'vue'

export default {
  name: 'WatcherExample',
  setup() {
    // Reactive data
    const watchedValue = ref('')
    const numberValue = ref(0)
    const changeMessage = ref('')
    const numberMessage = ref('')
    const validationMessage = ref('')
    const textChanges = ref(0)
    const numberChanges = ref(0)
    const changeHistory = ref([])
    const immediateTriggered = ref(false)
    const deepTriggered = ref(false)
    const debouncedTriggered = ref(false)

    // Computed properties
    const totalChanges = computed(() => textChanges.value + numberChanges.value)
    
    const validationClass = computed(() => {
      if (watchedValue.value.length < 3) return 'warning'
      if (watchedValue.value.length > 20) return 'error'
      return 'success'
    })

    const validationIcon = computed(() => {
      if (watchedValue.value.length < 3) return '⚠️'
      if (watchedValue.value.length > 20) return '❌'
      return '✅'
    })

    // Debounce function
    let debounceTimer
    const debounce = (func, delay) => {
      return (...args) => {
        clearTimeout(debounceTimer)
        debounceTimer = setTimeout(() => func(...args), delay)
      }
    }

    // Watchers
    
    // 1. Basic watcher for text changes
    watch(watchedValue, (newValue, oldValue) => {
      if (oldValue !== undefined && newValue !== oldValue) {
        textChanges.value++
        changeMessage.value = `"${oldValue}" → "${newValue}"`
        
        // Add to history
        changeHistory.value.push({
          type: 'text',
          from: oldValue,
          to: newValue,
          timestamp: new Date().toLocaleTimeString()
        })
        
        // Validation
        if (newValue.length < 3) {
          validationMessage.value = 'El texto es muy corto (mínimo 3 caracteres)'
        } else if (newValue.length > 20) {
          validationMessage.value = 'El texto es muy largo (máximo 20 caracteres)'
        } else {
          validationMessage.value = 'Longitud perfecta!'
        }
        
        // Clear message after 3 seconds
        setTimeout(() => {
          changeMessage.value = ''
        }, 3000)
      }
    })

    // 2. Watcher for number changes
    watch(numberValue, (newValue, oldValue) => {
      if (oldValue !== undefined && newValue !== oldValue) {
        numberChanges.value++
        const difference = newValue - oldValue
        const direction = difference > 0 ? 'aumentó' : 'disminuyó'
        numberMessage.value = `${oldValue} → ${newValue} (${direction} en ${Math.abs(difference)})`
        
        changeHistory.value.push({
          type: 'number',
          from: oldValue.toString(),
          to: newValue.toString(),
          timestamp: new Date().toLocaleTimeString()
        })
        
        setTimeout(() => {
          numberMessage.value = ''
        }, 3000)
      }
    })

    // 3. Immediate watcher
    watch(watchedValue, () => {
      immediateTriggered.value = true
      setTimeout(() => {
        immediateTriggered.value = false
      }, 2000)
    }, { immediate: true })

    // 4. Deep watcher for complex object
    const complexObject = ref({ nested: { value: '' } })
    watch(complexObject, () => {
      deepTriggered.value = true
      setTimeout(() => {
        deepTriggered.value = false
      }, 2000)
    }, { deep: true })

    // 5. Debounced watcher
    const debouncedWatcher = debounce(() => {
      debouncedTriggered.value = true
      setTimeout(() => {
        debouncedTriggered.value = false
      }, 2000)
    }, 500)

    watch(watchedValue, debouncedWatcher)

    // 6. watchEffect for automatic dependency tracking
    watchEffect(() => {
      // This will run whenever any reactive dependency changes
      console.log(`WatchEffect: Value is "${watchedValue.value}" with length ${watchedValue.value.length}`)
    })

    // Methods
    const clearHistory = () => {
      changeHistory.value = []
    }

    // Sync complex object with watched value for deep watcher demo
    watch(watchedValue, (newValue) => {
      complexObject.value.nested.value = newValue
    })

    return {
      watchedValue,
      numberValue,
      changeMessage,
      numberMessage,
      validationMessage,
      validationClass,
      validationIcon,
      textChanges,
      numberChanges,
      totalChanges,
      changeHistory,
      immediateTriggered,
      deepTriggered,
      debouncedTriggered,
      clearHistory
    }
  }
}
</script>

<style scoped>
.watcher-container {
  padding: 1.5rem;
}

.input-section {
  margin-bottom: 2rem;
}

.input-group {
  margin-bottom: 1.5rem;
}

.input-group label {
  display: block;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #374151;
}

.messages-section {
  min-height: 200px;
  margin-bottom: 2rem;
}

.message {
  display: flex;
  align-items: flex-start;
  gap: 1rem;
  margin-bottom: 1rem;
}

.message-icon {
  font-size: 1.5rem;
  flex-shrink: 0;
}

.message-content {
  flex: 1;
}

.change-detail {
  margin-top: 0.25rem;
  font-weight: normal;
  opacity: 0.9;
}

.stats-section {
  margin-bottom: 2rem;
}

.stats-section h4 {
  margin-bottom: 1rem;
  color: #374151;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
}

.stat-card {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 1.5rem;
  border-radius: 12px;
  text-align: center;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
}

.stat-number {
  font-size: 2rem;
  font-weight: bold;
}

.stat-label {
  font-size: 0.85rem;
  opacity: 0.9;
}

.history-section {
  margin-bottom: 2rem;
  background: #f9fafb;
  padding: 1.5rem;
  border-radius: 12px;
  border: 1px solid #e5e7eb;
}

.history-section h4 {
  margin-bottom: 1rem;
  color: #374151;
}

.history-list {
  margin-bottom: 1rem;
}

.history-item {
  background: white;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 0.75rem;
  border: 1px solid #e5e7eb;
}

.history-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}

.history-type {
  padding: 0.25rem 0.5rem;
  border-radius: 4px;
  font-size: 0.7rem;
  font-weight: bold;
  text-transform: uppercase;
}

.history-type.text {
  background: #dbeafe;
  color: #1e40af;
}

.history-type.number {
  background: #d1fae5;
  color: #065f46;
}

.history-time {
  font-size: 0.8rem;
  color: #6b7280;
}

.history-content {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-family: monospace;
  font-size: 0.9rem;
}

.history-from, .history-to {
  padding: 0.25rem 0.5rem;
  background: #f3f4f6;
  border-radius: 4px;
}

.history-arrow {
  color: #667eea;
  font-weight: bold;
}

.advanced-section {
  background: #f0f9ff;
  padding: 1.5rem;
  border-radius: 12px;
  border: 1px solid #bae6fd;
}

.advanced-section h4 {
  margin-bottom: 1rem;
  color: #0c4a6e;
}

.watcher-info {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.watcher-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem;
  background: white;
  border-radius: 8px;
  border: 1px solid #e0f2fe;
}

.watcher-label {
  font-weight: 600;
  color: #0c4a6e;
}

.watcher-status {
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-size: 0.85rem;
  font-weight: 500;
  background: #f1f5f9;
  color: #64748b;
  transition: all 0.3s ease;
}

.watcher-status.active {
  background: #dcfce7;
  color: #166534;
  transform: scale(1.05);
}

.btn-small {
  padding: 0.5rem 1rem;
  font-size: 0.85rem;
}

.fade-enter-active, .fade-leave-active {
  transition: all 0.3s ease;
}

.fade-enter-from, .fade-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}

@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .history-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }
  
  .history-content {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .watcher-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }
}
</style>