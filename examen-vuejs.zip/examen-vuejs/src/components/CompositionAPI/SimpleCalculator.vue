<template>
  <div class="calculator-container">
    <!-- Display -->
    <div class="calculator-display">
      <div class="display-operation" v-if="currentOperation">
        {{ num1 }} {{ operationSymbol }} {{ num2 }}
      </div>
      <div class="display-result">
        {{ displayValue }}
      </div>
    </div>

    <!-- Input Section -->
    <div class="input-section">
      <div class="input-row">
        <div class="input-group">
          <label>Número 1:</label>
          <input 
            v-model.number="num1" 
            type="number" 
            class="input-field" 
            placeholder="0"
            step="any"
          />
        </div>
        <div class="input-group">
          <label>Número 2:</label>
          <input 
            v-model.number="num2" 
            type="number" 
            class="input-field" 
            placeholder="0"
            step="any"
          />
        </div>
      </div>
    </div>

    <!-- Operation Buttons -->
    <div class="operations-grid">
      <button 
        @click="calculate('+')" 
        class="btn btn-operation"
        :class="{ active: currentOperation === '+' }"
      >
        <span class="op-symbol">+</span>
        <span class="op-name">Sumar</span>
      </button>
      
      <button 
        @click="calculate('-')" 
        class="btn btn-operation"
        :class="{ active: currentOperation === '-' }"
      >
        <span class="op-symbol">−</span>
        <span class="op-name">Restar</span>
      </button>
      
      <button 
        @click="calculate('*')" 
        class="btn btn-operation"
        :class="{ active: currentOperation === '*' }"
      >
        <span class="op-symbol">×</span>
        <span class="op-name">Multiplicar</span>
      </button>
      
      <button 
        @click="calculate('/')" 
        class="btn btn-operation"
        :class="{ active: currentOperation === '/' }"
      >
        <span class="op-symbol">÷</span>
        <span class="op-name">Dividir</span>
      </button>
    </div>

    <!-- Additional Controls -->
    <div class="controls-section">
      <button @click="clearAll" class="btn btn-secondary">
        🗑️ Limpiar Todo
      </button>
      <button @click="swapNumbers" class="btn btn-secondary">
        🔄 Intercambiar
      </button>
    </div>

    <!-- History -->
    <div v-if="history.length > 0" class="history-section">
      <h4>📊 Historial de Operaciones</h4>
      <div class="history-list">
        <div 
          v-for="(item, index) in history.slice(-5)" 
          :key="index" 
          class="history-item"
          @click="useHistoryResult(item)"
        >
          <span class="history-operation">{{ item.operation }}</span>
          <span class="history-result">= {{ item.result }}</span>
        </div>
      </div>
      <button @click="clearHistory" class="btn btn-warning btn-small">
        🧹 Limpiar Historial
      </button>
    </div>

    <!-- Error Message -->
    <div v-if="errorMessage" class="message error">
      ⚠️ {{ errorMessage }}
    </div>
  </div>
</template>

<script>
import { ref, computed, watch } from 'vue'

export default {
  name: 'SimpleCalculator',
  setup() {
    const num1 = ref(0)
    const num2 = ref(0)
    const result = ref(null)
    const currentOperation = ref('')
    const errorMessage = ref('')
    const history = ref([])

    // Computed properties
    const displayValue = computed(() => {
      if (errorMessage.value) return 'Error'
      if (result.value !== null) return formatNumber(result.value)
      return '0'
    })

    const operationSymbol = computed(() => {
      const symbols = {
        '+': '+',
        '-': '−',
        '*': '×',
        '/': '÷'
      }
      return symbols[currentOperation.value] || ''
    })

    // Methods
    const formatNumber = (num) => {
      if (typeof num !== 'number') return num
      if (Number.isInteger(num)) return num.toString()
      return Number(num.toFixed(8)).toString()
    }

    const calculate = (operation) => {
      errorMessage.value = ''
      currentOperation.value = operation
      
      const n1 = parseFloat(num1.value) || 0
      const n2 = parseFloat(num2.value) || 0
      
      let calculatedResult
      
      try {
        switch(operation) {
          case '+':
            calculatedResult = n1 + n2
            break
          case '-':
            calculatedResult = n1 - n2
            break
          case '*':
            calculatedResult = n1 * n2
            break
          case '/':
            if (n2 === 0) {
              throw new Error('División por cero no permitida')
            }
            calculatedResult = n1 / n2
            break
          default:
            throw new Error('Operación no válida')
        }
        
        result.value = calculatedResult
        
        // Add to history
        const operationString = `${n1} ${operationSymbol.value} ${n2}`
        history.value.push({
          operation: operationString,
          result: formatNumber(calculatedResult),
          timestamp: new Date().toLocaleTimeString()
        })
        
        // Keep only last 10 operations
        if (history.value.length > 10) {
          history.value = history.value.slice(-10)
        }
        
      } catch (error) {
        errorMessage.value = error.message
        result.value = null
      }
    }

    const clearAll = () => {
      num1.value = 0
      num2.value = 0
      result.value = null
      currentOperation.value = ''
      errorMessage.value = ''
    }

    const swapNumbers = () => {
      const temp = num1.value
      num1.value = num2.value
      num2.value = temp
    }

    const useHistoryResult = (historyItem) => {
      const resultValue = parseFloat(historyItem.result)
      if (!isNaN(resultValue)) {
        num1.value = resultValue
        num2.value = 0
        result.value = null
        currentOperation.value = ''
      }
    }

    const clearHistory = () => {
      history.value = []
    }

    // Watch for input changes to clear result
    watch([num1, num2], () => {
      if (result.value !== null) {
        result.value = null
        currentOperation.value = ''
        errorMessage.value = ''
      }
    })

    return {
      num1,
      num2,
      result,
      currentOperation,
      errorMessage,
      history,
      displayValue,
      operationSymbol,
      calculate,
      clearAll,
      swapNumbers,
      useHistoryResult,
      clearHistory
    }
  }
}
</script>

<style scoped>
.calculator-container {
  padding: 1.5rem;
  max-width: 500px;
  margin: 0 auto;
}

.calculator-display {
  background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
  color: white;
  padding: 1.5rem;
  border-radius: 15px;
  margin-bottom: 1.5rem;
  text-align: right;
  box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.2);
}

.display-operation {
  font-size: 1rem;
  opacity: 0.7;
  margin-bottom: 0.5rem;
  min-height: 1.2rem;
}

.display-result {
  font-size: 2.5rem;
  font-weight: bold;
  line-height: 1;
  word-break: break-all;
}

.input-section {
  margin-bottom: 1.5rem;
}

.input-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.input-group {
  display: flex;
  flex-direction: column;
}

.input-group label {
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #374151;
}

.operations-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.btn-operation {
  padding: 1rem;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: 2px solid transparent;
  transition: all 0.3s ease;
}

.btn-operation:hover {
  transform: translateY(-2px);
  border-color: #667eea;
}

.btn-operation.active {
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  border-color: #10b981;
}

.op-symbol {
  font-size: 1.5rem;
  font-weight: bold;
}

.op-name {
  font-size: 0.85rem;
  opacity: 0.9;
}

.controls-section {
  display: flex;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.controls-section .btn {
  flex: 1;
}

.btn-secondary {
  background: linear-gradient(135deg, #6b7280 0%, #4b5563 100%);
}

.history-section {
  background: #f9fafb;
  padding: 1rem;
  border-radius: 10px;
  border: 1px solid #e5e7eb;
}

.history-section h4 {
  margin-bottom: 1rem;
  color: #374151;
  font-size: 1rem;
}

.history-list {
  margin-bottom: 1rem;
}

.history-item {
  display: flex;
  justify-content: space-between;
  padding: 0.5rem;
  background: white;
  margin-bottom: 0.5rem;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.2s ease;
  font-size: 0.9rem;
}

.history-item:hover {
  background: #f3f4f6;
  transform: translateX(5px);
}

.history-operation {
  color: #6b7280;
}

.history-result {
  font-weight: 600;
  color: #059669;
}

.btn-small {
  padding: 0.5rem 1rem;
  font-size: 0.85rem;
}

@media (max-width: 768px) {
  .input-row {
    grid-template-columns: 1fr;
  }
  
  .operations-grid {
    grid-template-columns: 1fr;
  }
  
  .controls-section {
    flex-direction: column;
  }
  
  .display-result {
    font-size: 2rem;
  }
}</style>