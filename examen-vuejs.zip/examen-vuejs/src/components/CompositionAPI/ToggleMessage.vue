<template>
  <div class="toggle-container">
    <div class="control-section mb-3">
      <button @click="toggleMessage" class="btn">
        {{ isVisible ? '👁️ Ocultar' : '👀 Mostrar' }} Mensaje
      </button>
      
      <div class="toggle-stats">
        <small>Veces toggleado: {{ toggleCount }}</small>
      </div>
    </div>

    <transition name="slide">
      <div v-if="isVisible" class="message-container">
        <div class="message info">
          <span class="sparkle">✨</span>
          ¡Este es un mensaje que se puede mostrar u ocultar!
          <div class="message-timestamp">
            <small>Mostrado: {{ lastShown }}</small>
          </div>
        </div>
      </div>
    </transition>

    <div class="visibility-indicator">
      <span class="status-dot" :class="{ active: isVisible }"></span>
      <span>Estado: {{ isVisible ? 'Visible' : 'Oculto' }}</span>
    </div>
  </div>
</template>

<script>
import { ref, computed } from 'vue'

export default {
  name: 'ToggleMessage',
  setup() {
    const isVisible = ref(false)
    const toggleCount = ref(0)
    const lastShown = ref('')

    const toggleMessage = () => {
      isVisible.value = !isVisible.value
      toggleCount.value++
      
      if (isVisible.value) {
        lastShown.value = new Date().toLocaleTimeString()
      }
    }

    return {
      isVisible,
      toggleCount,
      lastShown,
      toggleMessage
    }
  }
}
</script>

<style scoped>
.toggle-container {
  padding: 1rem;
}

.control-section {
  text-align: center;
}

.toggle-stats {
  margin-top: 0.5rem;
  color: #6b7280;
}

.message-container {
  margin: 1rem 0;
}

.sparkle {
  margin-right: 0.5rem;
  animation: sparkle 2s infinite;
}

@keyframes sparkle {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.message-timestamp {
  margin-top: 0.5rem;
  opacity: 0.7;
}

.visibility-indicator {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.5rem;
  background: #f9fafb;
  border-radius: 8px;
  font-size: 0.9rem;
}

.status-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: #ef4444;
  transition: background-color 0.3s ease;
}

.status-dot.active {
  background: #10b981;
  box-shadow: 0 0 10px rgba(16, 185, 129, 0.5);
}

.slide-enter-active, .slide-leave-active {
  transition: all 0.4s ease;
}

.slide-enter-from {
  opacity: 0;
  transform: translateX(-20px);
}

.slide-leave-to {
  opacity: 0;
  transform: translateX(20px);
}
</style>