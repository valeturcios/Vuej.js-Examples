<template>
  <div class="theme-toggle">
    <button @click="toggleTheme">
      {{ isDark ? '🌙 Modo Oscuro' : '☀️ Modo Claro' }}
    </button>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const isDark = ref(false)

const toggleTheme = () => {
  isDark.value = !isDark.value
  // 🚀 Emitimos el estado hacia el padre
  emit('theme-changed', isDark.value)
}

const emit = defineEmits(['theme-changed'])
</script>

<style scoped>
.theme-toggle button {
  padding: 0.7rem 1.2rem;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  font-weight: bold;
  background: #4f46e5;
  color: white;
  transition: all 0.3s ease;
}
.theme-toggle button:hover {
  background: #4338ca;
}
</style>
