<template>
  <div class="welcome-container">
    <div class="input-group mb-3">
      <input 
        v-model="welcomeData.name" 
        class="input-field" 
        placeholder="Ingresa tu nombre"
        @keyup.enter="focusInput"
      />
    </div>
    
    <transition name="fade">
      <div v-if="welcomeData.name.trim()" class="message success">
        <span class="welcome-icon">🎉</span>
        ¡Bienvenido/a, <strong>{{ welcomeData.name }}</strong>!
        <div class="welcome-details">
          <small>Longitud del nombre: {{ welcomeData.name.length }} caracteres</small>
        </div>
      </div>
    </transition>

    <div v-if="!welcomeData.name.trim()" class="message info">
      <span class="info-icon">ℹ️</span>
      Escribe tu nombre para ver el mensaje de bienvenida
    </div>
  </div>
</template>

<script>
import { reactive } from 'vue'

export default {
  name: 'WelcomeMessage',
  setup() {
    // Usando reactive para crear un objeto reactivo
    const welcomeData = reactive({
      name: ''
    })

    const focusInput = () => {
      console.log('Mensaje enviado:', welcomeData.name)
    }

    return {
      welcomeData,
      focusInput
    }
  }
}
</script>

<style scoped>
.welcome-container {
  padding: 1rem;
}

.input-group {
  margin-bottom: 1rem;
}

.welcome-icon, .info-icon {
  margin-right: 0.5rem;
  font-size: 1.2rem;
}

.welcome-details {
  margin-top: 0.5rem;
  opacity: 0.8;
}

.welcome-details small {
  font-size: 0.85rem;
}

.fade-enter-active, .fade-leave-active {
  transition: all 0.3s ease;
}

.fade-enter-from, .fade-leave-to {
  opacity: 0;
  transform: translateY(-10px);
}
</style>