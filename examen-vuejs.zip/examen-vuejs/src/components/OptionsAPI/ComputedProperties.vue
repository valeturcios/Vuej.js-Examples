<template>
  <div class="computed-properties-container">
    <!-- Input Section -->
    <div class="input-section">
      <div class="input-grid">
        <div class="input-group">
          <label for="first-name">👤 Nombre:</label>
          <input 
            id="first-name"
            v-model="firstName" 
            class="input-field" 
            placeholder="Ingresa tu nombre"
            @input="trackChange('firstName')"
          />
        </div>
        
        <div class="input-group">
          <label for="last-name">👥 Apellido:</label>
          <input 
            id="last-name"
            v-model="lastName" 
            class="input-field" 
            placeholder="Ingresa tu apellido"
            @input="trackChange('lastName')"
          />
        </div>

        <div class="input-group">
          <label for="middle-name">🎭 Segundo Nombre (Opcional):</label>
          <input 
            id="middle-name"
            v-model="middleName" 
            class="input-field" 
            placeholder="Segundo nombre"
            @input="trackChange('middleName')"
          />
        </div>

        <div class="input-group">
          <label for="title">🎓 Título (Opcional):</label>
          <select 
            id="title"
            v-model="title" 
            class="input-field"
            @change="trackChange('title')"
          >
            <option value="">Sin título</option>
            <option value="Dr.">Dr.</option>
            <option value="Dra.">Dra.</option>
            <option value="Ing.">Ing.</option>
            <option value="Lic.">Lic.</option>
            <option value="Prof.">Prof.</option>
            <option value="Sr.">Sr.</option>
            <option value="Sra.">Sra.</option>
            <option value="Srta.">Srta.</option>
          </select>
        </div>
      </div>
    </div>

    <!-- Results Display -->
    <div class="results-section">
      <div class="result-card main-result">
        <h3>🏷️ Nombre Completo</h3>
        <div class="full-name-display">
          <span v-if="!fullName.trim()" class="empty-state">
            Ingresa tu nombre para ver el resultado...
          </span>
          <span v-else class="full-name-text">{{ fullName }}</span>
        </div>
        <div v-if="fullName.trim()" class="name-details">
          <div class="detail-item">
            <span class="detail-label">Longitud total:</span>
            <span class="detail-value">{{ fullNameLength }} caracteres</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Número de palabras:</span>
            <span class="detail-value">{{ wordCount }}</span>
          </div>
        </div>
      </div>

      <div class="computed-grid">
        <div class="result-card">
          <h4>📝 Iniciales</h4>
          <div class="computed-result">
            {{ initials || 'N/A' }}
          </div>
        </div>

        <div class="result-card">
          <h4>🔠 Formato Formal</h4>
          <div class="computed-result formal">
            {{ formalName || 'N/A' }}
          </div>
        </div>

        <div class="result-card">
          <h4>👋 Saludo Personalizado</h4>
          <div class="computed-result greeting">
            {{ personalizedGreeting }}
          </div>
        </div>

        <div class="result-card">
          <h4>🏷️ Nombre de Usuario</h4>
          <div class="computed-result username">
            {{ suggestedUsername || 'N/A' }}
          </div>
        </div>
      </div>
    </div>

    <!-- Advanced Computed Properties -->
    <div class="advanced-section">
      <h3>🧮 Propiedades Computadas Avanzadas</h3>
      
      <div class="advanced-grid">
        <div class="advanced-card">
          <div class="advanced-header">
            <span class="advanced-icon">📊</span>
            <h4>Análisis de Nombre</h4>
          </div>
          <div class="advanced-content">
            <div class="analysis-item">
              <span class="analysis-label">Complejidad:</span>
              <span class="analysis-value" :class="complexityLevel.class">
                {{ complexityLevel.text }}
              </span>
            </div>
            <div class="analysis-item">
              <span class="analysis-label">Tipo:</span>
              <span class="analysis-value">{{ nameType }}</span>
            </div>
            <div class="analysis-item">
              <span class="analysis-label">Contiene números:</span>
              <span class="analysis-value">{{ hasNumbers ? 'Sí' : 'No' }}</span>
            </div>
          </div>
        </div>

        <div class="advanced-card">
          <div class="advanced-header">
            <span class="advanced-icon">🎨</span>
            <h4>Formatos Alternativos</h4>
          </div>
          <div class="advanced-content">
            <div class="format-item">
              <span class="format-label">MAYÚSCULAS:</span>
              <span class="format-value">{{ uppercaseName }}</span>
            </div>
            <div class="format-item">
              <span class="format-label">minúsculas:</span>
              <span class="format-value">{{ lowercaseName }}</span>
            </div>
            <div class="format-item">
              <span class="format-label">Invertido:</span>
              <span class="format-value">{{ reversedName }}</span>
            </div>
          </div>
        </div>

        <div class="advanced-card">
          <div class="advanced-header">
            <span class="advanced-icon">⚡</span>
            <h4>Estadísticas en Tiempo Real</h4>
          </div>
          <div class="advanced-content">
            <div class="stat-item">
              <span class="stat-number">{{ changeCount }}</span>
              <span class="stat-label">Cambios realizados</span>
            </div>
            <div class="stat-item">
              <span class="stat-number">{{ computedCalculations }}</span>
              <span class="stat-label">Cálculos automáticos</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Interactive Preview -->
    <div class="preview-section">
      <h3>👀 Vista Previa Interactiva</h3>
      <div class="preview-cards">
        <div class="preview-card business-card">
          <div class="card-header">💼 Tarjeta de Presentación</div>
          <div class="card-content">
            <div class="card-name">{{ formalName || 'Nombre Completo' }}</div>
            <div class="card-title">{{ title ? `${title}` : 'Título Profesional' }}</div>
            <div class="card-initials">{{ initials || 'XX' }}</div>
          </div>
        </div>

        <div class="preview-card name-badge">
          <div class="badge-header">🏷️ Gafete de Identificación</div>
          <div class="badge-content">
            <div class="badge-hello">¡Hola! Mi nombre es</div>
            <div class="badge-name">{{ firstName || 'TU NOMBRE' }}</div>
            <div class="badge-full">{{ fullName || 'Nombre completo aquí' }}</div>
          </div>
        </div>

        <div class="preview-card email-signature">
          <div class="signature-header">📧 Firma de Email</div>
          <div class="signature-content">
            <div class="signature-name">{{ fullName || 'Tu Nombre' }}</div>
            <div class="signature-username">{{ suggestedUsername || 'usuario' }}@empresa.com</div>
            <div class="signature-greeting">{{ personalizedGreeting }}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ComputedProperties',
  data() {
    return {
      firstName: '',
      lastName: '',
      middleName: '',
      title: '',
      changeCount: 0,
      computedCalculations: 0
    }
  },
  computed: {
    // Basic computed property
    fullName() {
      this.computedCalculations++
      const parts = []
      if (this.title) parts.push(this.title)
      if (this.firstName) parts.push(this.firstName)
      if (this.middleName) parts.push(this.middleName)
      if (this.lastName) parts.push(this.lastName)
      return parts.join(' ').trim()
    },

    // Length calculation
    fullNameLength() {
      this.computedCalculations++
      return this.fullName.length
    },

    // Word count
    wordCount() {
      this.computedCalculations++
      if (!this.fullName.trim()) return 0
      return this.fullName.trim().split(/\s+/).length
    },

    // Initials
    initials() {
      this.computedCalculations++
      const parts = [this.firstName, this.middleName, this.lastName]
        .filter(part => part && part.trim())
        .map(part => part.charAt(0).toUpperCase())
      return parts.join('.')
    },

    // Formal name format
    formalName() {
      this.computedCalculations++
      if (!this.lastName || !this.firstName) return this.fullName
      return `${this.lastName}, ${this.firstName}${this.middleName ? ' ' + this.middleName : ''}`
    },

    // Personalized greeting
    personalizedGreeting() {
      this.computedCalculations++
      if (!this.firstName.trim()) return '👋 ¡Hola! Ingresa tu nombre para un saludo personalizado.'
      
      const timeOfDay = new Date().getHours()
      let greeting
      
      if (timeOfDay < 12) greeting = 'Buenos días'
      else if (timeOfDay < 18) greeting = 'Buenas tardes'
      else greeting = 'Buenas noches'
      
      return `${greeting}, ${this.firstName}! 😊`
    },

    // Username suggestion
    suggestedUsername() {
      this.computedCalculations++
      if (!this.firstName && !this.lastName) return ''
      
      const first = this.firstName.toLowerCase().replace(/\s/g, '')
      const last = this.lastName.toLowerCase().replace(/\s/g, '')
      
      if (first && last) {
        return `${first}.${last}`
      } else if (first) {
        return first
      } else if (last) {
        return last
      }
      return ''
    },

    // Name complexity analysis
    complexityLevel() {
      this.computedCalculations++
      const length = this.fullName.length
      
      if (length === 0) return { text: 'Sin datos', class: 'empty' }
      if (length < 10) return { text: 'Simple', class: 'simple' }
      if (length < 20) return { text: 'Moderado', class: 'moderate' }
      if (length < 35) return { text: 'Complejo', class: 'complex' }
      return { text: 'Muy Complejo', class: 'very-complex' }
    },

    // Name type analysis
    nameType() {
      this.computedCalculations++
      if (!this.fullName.trim()) return 'Sin clasificar'
      
      const hasTitle = !!this.title
      const hasMiddle = !!this.middleName.trim()
      const parts = this.wordCount
      
      if (hasTitle && hasMiddle) return 'Formal Completo'
      if (hasTitle) return 'Formal'
      if (hasMiddle) return 'Con segundo nombre'
      if (parts === 2) return 'Estándar'
      if (parts === 1) return 'Nombre único'
      return 'Personalizado'
    },

    // Check for numbers
    hasNumbers() {
      this.computedCalculations++
      return /\d/.test(this.fullName)
    },

    // Different case formats
    uppercaseName() {
      this.computedCalculations++
      return this.fullName.toUpperCase()
    },

    lowercaseName() {
      this.computedCalculations++
      return this.fullName.toLowerCase()
    },

    reversedName() {
      this.computedCalculations++
      return this.fullName.split('').reverse().join('')
    }
  },
  methods: {
    trackChange(field) {
      this.changeCount++
      console.log(`Campo ${field} modificado. Total de cambios: ${this.changeCount}`)
    }
  }
}
</script>

<style scoped>
.computed-properties-container {
  padding: 2rem;
}

.input-section {
  margin-bottom: 2rem;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  padding: 2rem;
  border-radius: 20px;
  border: 1px solid #cbd5e1;
}

.input-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.input-group {
  display: flex;
  flex-direction: column;
}

.input-group label {
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #374151;
  font-size: 0.9rem;
}

.results-section {
  margin-bottom: 3rem;
}

.main-result {
  margin-bottom: 2rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  text-align: center;
}

.main-result h3 {
  font-size: 1.5rem;
  margin-bottom: 1rem;
}

.full-name-display {
  margin-bottom: 1.5rem;
}

.empty-state {
  font-style: italic;
  opacity: 0.8;
  font-size: 1.1rem;
}

.full-name-text {
  font-size: 2.5rem;
  font-weight: bold;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
  word-break: break-word;
}

.name-details {
  display: flex;
  justify-content: center;
  gap: 2rem;
  flex-wrap: wrap;
}

.detail-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.25rem;
}

.detail-label {
  font-size: 0.85rem;
  opacity: 0.9;
}

.detail-value {
  font-size: 1.2rem;
  font-weight: bold;
}

.computed-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.result-card {
  background: white;
  padding: 1.5rem;
  border-radius: 15px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  border: 1px solid #e5e7eb;
  text-align: center;
}

.result-card h4 {
  margin-bottom: 1rem;
  color: #374151;
  font-size: 1rem;
}

.computed-result {
  font-size: 1.3rem;
  font-weight: bold;
  color: #667eea;
  min-height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  word-break: break-word;
}

.computed-result.formal {
  color: #059669;
}

.computed-result.greeting {
  color: #f59e0b;
  font-size: 1rem;
  line-height: 1.4;
}

.computed-result.username {
  color: #8b5cf6;
  font-family: monospace;
}

.advanced-section {
  margin-bottom: 3rem;
}

.advanced-section h3 {
  margin-bottom: 2rem;
  color: #1f2937;
  text-align: center;
}

.advanced-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
}

.advanced-card {
  background: white;
  border-radius: 15px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  border: 1px solid #e5e7eb;
}

.advanced-header {
  background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
  padding: 1rem 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.75rem;
  border-bottom: 1px solid #e5e7eb;
}

.advanced-icon {
  font-size: 1.5rem;
}

.advanced-header h4 {
  color: #374151;
  margin: 0;
}

.advanced-content {
  padding: 1.5rem;
}

.analysis-item, .format-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem;
  margin-bottom: 0.75rem;
  background: #f9fafb;
  border-radius: 8px;
  border: 1px solid #f3f4f6;
}

.analysis-label, .format-label {
  font-weight: 500;
  color: #6b7280;
}

.analysis-value, .format-value {
  font-weight: 600;
  color: #374151;
}

.analysis-value.simple { color: #10b981; }
.analysis-value.moderate { color: #3b82f6; }
.analysis-value.complex { color: #f59e0b; }
.analysis-value.very-complex { color: #ef4444; }
.analysis-value.empty { color: #6b7280; }

.stat-item {
  text-align: center;
  padding: 1rem;
  background: #f0f9ff;
  border-radius: 8px;
  border: 1px solid #bae6fd;
  margin-bottom: 0.75rem;
}

.stat-number {
  display: block;
  font-size: 2rem;
  font-weight: bold;
  color: #0369a1;
  line-height: 1;
}

.stat-label {
  font-size: 0.85rem;
  color: #0c4a6e;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin-top: 0.25rem;
}

.preview-section {
  margin-bottom: 2rem;
}

.preview-section h3 {
  margin-bottom: 2rem;
  color: #1f2937;
  text-align: center;
}

.preview-cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2rem;
}

.preview-card {
  background: white;
  border-radius: 15px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
  overflow: hidden;
  border: 2px solid #e5e7eb;
  transition: all 0.3s ease;
}

.preview-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
}

.business-card {
  background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
  color: white;
}

.business-card .card-header {
  background: rgba(255, 255, 255, 0.1);
  padding: 1rem;
  text-align: center;
  font-weight: 600;
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}

.business-card .card-content {
  padding: 2rem;
  text-align: center;
  position: relative;
}

.card-name {
  font-size: 1.8rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
  color: #f8fafc;
}

.card-title {
  font-size: 1rem;
  color: #cbd5e1;
  margin-bottom: 1.5rem;
}

.card-initials {
  position: absolute;
  top: 1rem;
  right: 1.5rem;
  font-size: 2.5rem;
  font-weight: bold;
  color: #64748b;
  opacity: 0.3;
}

.name-badge {
  background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
  color: white;
}

.badge-header {
  background: rgba(0, 0, 0, 0.2);
  padding: 0.75rem;
  text-align: center;
  font-weight: 600;
  font-size: 0.9rem;
}

.badge-content {
  padding: 2rem;
  text-align: center;
}

.badge-hello {
  font-size: 0.9rem;
  margin-bottom: 1rem;
  opacity: 0.9;
}

.badge-name {
  font-size: 2.2rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

.badge-full {
  font-size: 1rem;
  opacity: 0.8;
}

.email-signature {
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  color: #1f2937;
}

.signature-header {
  background: #667eea;
  color: white;
  padding: 1rem;
  text-align: center;
  font-weight: 600;
}

.signature-content {
  padding: 2rem;
  border-left: 4px solid #667eea;
  background: white;
}

.signature-name {
  font-size: 1.4rem;
  font-weight: bold;
  color: #1f2937;
  margin-bottom: 0.5rem;
}

.signature-username {
  color: #667eea;
  font-family: monospace;
  font-size: 0.9rem;
  margin-bottom: 1rem;
}

.signature-greeting {
  color: #6b7280;
  font-style: italic;
  border-top: 1px solid #e5e7eb;
  padding-top: 1rem;
  margin-top: 1rem;
}

/* Responsive Design */
@media (max-width: 768px) {
  .computed-properties-container {
    padding: 1rem;
  }
  
  .input-grid {
    grid-template-columns: 1fr;
  }
  
  .computed-grid {
    grid-template-columns: 1fr;
  }
  
  .advanced-grid {
    grid-template-columns: 1fr;
  }
  
  .preview-cards {
    grid-template-columns: 1fr;
  }
  
  .full-name-text {
    font-size: 2rem;
  }
  
  .name-details {
    flex-direction: column;
    gap: 1rem;
  }
  
  .card-initials {
    position: relative;
    top: auto;
    right: auto;
    margin-top: 1rem;
  }
}

@media (max-width: 480px) {
  .input-section {
    padding: 1rem;
  }
  
  .main-result {
    padding: 1rem;
  }
  
  .full-name-text {
    font-size: 1.5rem;
  }
  
  .advanced-content {
    padding: 1rem;
  }
  
  .analysis-item, .format-item {
    flex-direction: column;
    gap: 0.5rem;
    text-align: center;
  }
}
</style>