<template>
  <div class="input-handler-container">
    <!-- Main Input Section -->
    <div class="input-section">
      <div class="input-group">
        <label for="main-input">💬 Ingresa tu mensaje:</label>
        <input 
          id="main-input"
          v-model="inputValue" 
          class="input-field" 
          placeholder="Escribe algo aquí..."
          @keyup.enter="showAlert"
          @focus="handleFocus"
          @blur="handleBlur"
          @input="handleInput"
        />
      </div>

      <div class="action-buttons">
        <button 
          @click="showAlert" 
          class="btn btn-primary"
          :disabled="!inputValue.trim()"
        >
          <span class="btn-icon">📢</span>
          Mostrar Alerta
        </button>
        
        <button 
          @click="copyToClipboard" 
          class="btn btn-secondary"
          :disabled="!inputValue.trim()"
        >
          <span class="btn-icon">📋</span>
          Copiar Texto
        </button>
        
        <button @click="clearInput" class="btn btn-warning">
          <span class="btn-icon">🧹</span>
          Limpiar
        </button>
      </div>
    </div>

    <!-- Real-time Display -->
    <div class="display-section">
      <div v-if="inputValue.trim()" class="message success">
        <div class="message-header">
          <span class="message-icon">✨</span>
          <strong>Texto actual:</strong>
        </div>
        <div class="message-content">
          "{{ inputValue }}"
        </div>
        <div class="message-details">
          <small>
            Longitud: {{ inputValue.length }} caracteres | 
            Palabras: {{ wordCount }} | 
            Sin espacios: {{ inputValue.replace(/\s/g, '').length }}
          </small>
        </div>
      </div>

      <div v-else class="message info">
        <span class="message-icon">💡</span>
        <strong>Consejo:</strong> Escribe algo y presiona Enter o haz clic en "Mostrar Alerta"
      </div>
    </div>

    <!-- Event Status -->
    <div class="events-section">
      <h4>🎯 Estado de Eventos</h4>
      <div class="events-grid">
        <div class="event-item" :class="{ active: isFocused }">
          <span class="event-icon">🎯</span>
          <span class="event-label">Focus</span>
          <span class="event-status">{{ isFocused ? 'Activo' : 'Inactivo' }}</span>
        </div>
        
        <div class="event-item" :class="{ active: lastEvent === 'input' }">
          <span class="event-icon">⌨️</span>
          <span class="event-label">Input</span>
          <span class="event-status">{{ inputEventCount }} eventos</span>
        </div>
        
        <div class="event-item" :class="{ active: lastEvent === 'blur' }">
          <span class="event-icon">👁️</span>
          <span class="event-label">Blur</span>
          <span class="event-status">{{ blurCount }} veces</span>
        </div>
        
        <div class="event-item" :class="{ active: lastEvent === 'enter' }">
          <span class="event-icon">↩️</span>
          <span class="event-label">Enter</span>
          <span class="event-status">{{ enterCount }} veces</span>
        </div>
      </div>
    </div>

    <!-- Input Analysis -->
    <div class="analysis-section">
      <h4>🔍 Análisis del Texto</h4>
      <div class="analysis-grid">
        <div class="analysis-item">
          <span class="analysis-label">Tipo de contenido:</span>
          <span class="analysis-value">{{ contentType }}</span>
        </div>
        <div class="analysis-item">
          <span class="analysis-label">Caracteres especiales:</span>
          <span class="analysis-value">{{ specialCharCount }}</span>
        </div>
        <div class="analysis-item">
          <span class="analysis-label">Solo números:</span>
          <span class="analysis-value">{{ isNumeric ? 'Sí' : 'No' }}</span>
        </div>
        <div class="analysis-item">
          <span class="analysis-label">Contiene email:</span>
          <span class="analysis-value">{{ hasEmail ? 'Sí' : 'No' }}</span>
        </div>
      </div>
    </div>

    <!-- Recent Actions -->
    <div v-if="recentActions.length > 0" class="actions-section">
      <h4>📋 Acciones Recientes</h4>
      <div class="actions-list">
        <div 
          v-for="(action, index) in recentActions.slice(-5)" 
          :key="index"
          class="action-item"
          :class="action.type"
        >
          <span class="action-description">{{ action.description }}</span>
          <span class="action-time">{{ action.time }}</span>
        </div>
      </div>
    </div>

    <!-- Live Typing Indicator -->
    <div v-if="isTyping" class="typing-indicator">
      <div class="typing-dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
      <span class="typing-text">Escribiendo...</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'InputHandler',
  data() {
    return {
      inputValue: '',
      isFocused: false,
      inputEventCount: 0,
      blurCount: 0,
      enterCount: 0,
      lastEvent: '',
      recentActions: [],
      isTyping: false,
      typingTimer: null
    }
  },
  computed: {
    wordCount() {
      if (!this.inputValue.trim()) return 0
      return this.inputValue.trim().split(/\s+/).length
    },
    contentType() {
      if (!this.inputValue.trim()) return 'Vacío'
      if (this.isNumeric) return 'Numérico'
      if (this.hasEmail) return 'Contiene Email'
      if (/^[a-zA-Z\s]+$/.test(this.inputValue)) return 'Solo texto'
      return 'Mixto'
    },
    specialCharCount() {
      const specialChars = this.inputValue.match(/[^a-zA-Z0-9\s]/g)
      return specialChars ? specialChars.length : 0
    },
    isNumeric() {
      return /^\d+$/.test(this.inputValue.trim()) && this.inputValue.trim() !== ''
    },
    hasEmail() {
      const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/
      return emailRegex.test(this.inputValue)
    }
  },
  methods: {
    showAlert() {
      if (this.inputValue.trim()) {
        alert(`📢 El valor del input es: "${this.inputValue}"`)
        this.addAction('alert', `Alerta mostrada: "${this.inputValue}"`)
        this.enterCount++
        this.lastEvent = 'enter'
      } else {
        alert('⚠️ ¡El campo está vacío!')
        this.addAction('alert', 'Intento de alerta con campo vacío')
      }
    },
    handleFocus() {
      this.isFocused = true
      this.lastEvent = 'focus'
      this.addAction('focus', 'Campo enfocado')
    },
    handleBlur() {
      this.isFocused = false
      this.blurCount++
      this.lastEvent = 'blur'
      this.addAction('blur', 'Campo desenfocado')
      this.isTyping = false
    },
    handleInput() {
      this.inputEventCount++
      this.lastEvent = 'input'
      
      // Typing indicator
      this.isTyping = true
      clearTimeout(this.typingTimer)
      this.typingTimer = setTimeout(() => {
        this.isTyping = false
      }, 1000)
    },
    copyToClipboard() {
      if (this.inputValue.trim()) {
        navigator.clipboard.writeText(this.inputValue).then(() => {
          this.addAction('copy', `Texto copiado: "${this.inputValue}"`)
          alert('📋 ¡Texto copiado al portapapeles!')
        }).catch(() => {
          this.addAction('copy', 'Error al copiar texto')
          alert('❌ Error al copiar al portapapeles')
        })
      }
    },
    clearInput() {
      const oldValue = this.inputValue
      this.inputValue = ''
      this.addAction('clear', `Campo limpiado. Valor anterior: "${oldValue}"`)
      this.isTyping = false
    },
    addAction(type, description) {
      this.recentActions.push({
        type,
        description,
        time: new Date().toLocaleTimeString()
      })
      
      // Keep only last 10 actions
      if (this.recentActions.length > 10) {
        this.recentActions = this.recentActions.slice(-10)
      }
    }
  },
  mounted() {
    this.addAction('system', 'Componente de manejo de input inicializado')
  }
}
</script>

<style scoped>
.input-handler-container {
  padding: 1.5rem;
}

.input-section {
  margin-bottom: 2rem;
}

.input-group {
  margin-bottom: 1.5rem;
}

.input-group label {
  display: block;
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #374151;
}

.action-buttons {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}

.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1.5rem;
  font-weight: 600;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
}

.btn-primary {
  background: linear-gradient(45deg, #3b82f6, #1d4ed8);
  color: white;
}

.btn-secondary {
  background: linear-gradient(45deg, #6b7280, #4b5563);
  color: white;
}

.btn-warning {
  background: linear-gradient(45deg, #f59e0b, #d97706);
  color: white;
}

.btn-icon {
  font-size: 1.1rem;
}

.display-section {
  margin-bottom: 2rem;
}

.message {
  padding: 1.5rem;
  border-radius: 12px;
  margin-bottom: 1rem;
}

.message-header {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.75rem;
}

.message-icon {
  font-size: 1.3rem;
}

.message-content {
  font-size: 1.1rem;
  font-weight: 500;
  margin-bottom: 0.5rem;
  padding: 0.75rem;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 8px;
  font-family: monospace;
}

.message-details {
  color: rgba(0, 0, 0, 0.7);
}

.events-section {
  margin-bottom: 2rem;
  background: #f8fafc;
  padding: 1.5rem;
  border-radius: 15px;
  border: 1px solid #e2e8f0;
}

.events-section h4 {
  margin-bottom: 1rem;
  color: #1e293b;
}

.events-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
}

.event-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem;
  background: white;
  border-radius: 10px;
  border: 2px solid #e2e8f0;
  transition: all 0.3s ease;
}

.event-item.active {
  border-color: #10b981;
  background: #ecfdf5;
  transform: scale(1.05);
}

.event-icon {
  font-size: 1.5rem;
}

.event-label {
  font-weight: 600;
  color: #374151;
}

.event-status {
  font-size: 0.85rem;
  color: #6b7280;
}

.analysis-section {
  margin-bottom: 2rem;
  background: #fefce8;
  padding: 1.5rem;
  border-radius: 15px;
  border: 1px solid #fde047;
}

.analysis-section h4 {
  margin-bottom: 1rem;
  color: #a16207;
}

.analysis-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
}

.analysis-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem;
  background: white;
  border-radius: 8px;
  border: 1px solid #fbbf24;
}

.analysis-label {
  font-weight: 500;
  color: #92400e;
}

.analysis-value {
  font-weight: 600;
  color: #1f2937;
}

.actions-section {
  margin-bottom: 2rem;
  background: #f0f9ff;
  padding: 1.5rem;
  border-radius: 15px;
  border: 1px solid #bae6fd;
}

.actions-section h4 {
  margin-bottom: 1rem;
  color: #0c4a6e;
}

.actions-list {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.action-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem;
  background: white;
  border-radius: 8px;
  border-left: 4px solid;
}

.action-item.alert {
  border-left-color: #3b82f6;
}

.action-item.focus {
  border-left-color: #10b981;
}

.action-item.blur {
  border-left-color: #f59e0b;
}

.action-item.copy {
  border-left-color: #8b5cf6;
}

.action-item.clear {
  border-left-color: #ef4444;
}

.action-item.system {
  border-left-color: #6b7280;
}

.action-description {
  font-weight: 500;
  color: #374151;
}

.action-time {
  font-size: 0.85rem;
  color: #6b7280;
}

.typing-indicator {
  position: fixed;
  bottom: 2rem;
  right: 2rem;
  background: #1f2937;
  color: white;
  padding: 1rem 1.5rem;
  border-radius: 25px;
  display: flex;
  align-items: center;
  gap: 1rem;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  z-index: 1000;
}

.typing-dots {
  display: flex;
  gap: 0.25rem;
}

.typing-dots span {
  width: 6px;
  height: 6px;
  background: #10b981;
  border-radius: 50%;
  animation: typing 1.4s infinite ease-in-out;
}

.typing-dots span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-dots span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 80%, 100% {
    transform: scale(0.8);
    opacity: 0.5;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}

.typing-text {
  font-size: 0.9rem;
  font-weight: 500;
}

@media (max-width: 768px) {
  .action-buttons {
    flex-direction: column;
  }
  
  .events-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .analysis-grid {
    grid-template-columns: 1fr;
  }
  
  .typing-indicator {
    bottom: 1rem;
    right: 1rem;
    padding: 0.75rem 1rem;
  }
}
</style>