<template>
  <div class="counter-container">
    <!-- Main Counter Display -->
    <div class="counter-display">
      <div class="counter-number">{{ count }}</div>
      <div class="counter-label">
        {{ count === 1 ? 'Clic' : 'Clics' }}
      </div>
    </div>

    <!-- Control Buttons -->
    <div class="controls-section">
      <div class="primary-controls">
        <button 
          @click="increment" 
          class="btn btn-primary"
          :disabled="count >= 100"
        >
          <span class="btn-icon">➕</span>
          Incrementar
        </button>
        
        <button 
          @click="decrement" 
          class="btn btn-secondary"
          :disabled="count <= 0"
        >
          <span class="btn-icon">➖</span>
          Decrementar
        </button>
      </div>

      <div class="secondary-controls">
        <button @click="addFive" class="btn btn-success">+5</button>
        <button @click="subtractFive" class="btn btn-warning">-5</button>
        <button @click="reset" class="btn btn-danger">🔄 Reset</button>
      </div>
    </div>

    <!-- Status Messages -->
    <div class="status-section">
      <div v-if="count === 0" class="message info">
        🎯 ¡Comienza haciendo clic en incrementar!
      </div>
      <div v-else-if="count >= 50 && count < 100" class="message warning">
        ⚠️ ¡Estás cerca del límite! ({{ 100 - count }} clics restantes)
      </div>
      <div v-else-if="count >= 100" class="message error">
        🚫 ¡Has alcanzado el límite máximo de 100 clics!
      </div>
      <div v-else-if="count === 42" class="message success">
        🎉 ¡Has encontrado la respuesta a la vida, el universo y todo!
      </div>
      <div v-else-if="count % 10 === 0 && count > 0" class="message success">
        ⭐ ¡Múltiplo de 10! Buen trabajo.
      </div>
    </div>

    <!-- Statistics -->
    <div class="stats-section">
      <h4>📊 Estadísticas</h4>
      <div class="stats-grid">
        <div class="stat-item">
          <span class="stat-value">{{ totalClicks }}</span>
          <span class="stat-label">Total de Clics</span>
        </div>
        <div class="stat-item">
          <span class="stat-value">{{ incrementCount }}</span>
          <span class="stat-label">Incrementos</span>
        </div>
        <div class="stat-item">
          <span class="stat-value">{{ decrementCount }}</span>
          <span class="stat-label">Decrementos</span>
        </div>
        <div class="stat-item">
          <span class="stat-value">{{ resetCount }}</span>
          <span class="stat-label">Resets</span>
        </div>
      </div>
    </div>

    <!-- Progress Bar -->
    <div class="progress-section">
      <div class="progress-label">
        Progreso hacia 100: {{ Math.round(progressPercentage) }}%
      </div>
      <div class="progress-bar">
        <div 
          class="progress-fill" 
          :style="{ width: progressPercentage + '%' }"
          :class="progressClass"
        ></div>
      </div>
    </div>

    <!-- History -->
    <div v-if="history.length > 0" class="history-section">
      <h4>📈 Últimas Acciones</h4>
      <div class="history-list">
        <div 
          v-for="(action, index) in history.slice(-5)" 
          :key="index"
          class="history-item"
          :class="action.type"
        >
          <span class="history-action">{{ action.description }}</span>
          <span class="history-time">{{ action.time }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ClickCounter',
  data() {
    return {
      count: 0,
      totalClicks: 0,
      incrementCount: 0,
      decrementCount: 0,
      resetCount: 0,
      history: []
    }
  },
  computed: {
    progressPercentage() {
      return Math.min((this.count / 100) * 100, 100)
    },
    progressClass() {
      if (this.progressPercentage >= 100) return 'complete'
      if (this.progressPercentage >= 75) return 'high'
      if (this.progressPercentage >= 50) return 'medium'
      return 'low'
    }
  },
  methods: {
    increment() {
      if (this.count < 100) {
        this.count++
        this.incrementCount++
        this.totalClicks++
        this.addToHistory('increment', `Incrementado a ${this.count}`)
      }
    },
    decrement() {
      if (this.count > 0) {
        this.count--
        this.decrementCount++
        this.totalClicks++
        this.addToHistory('decrement', `Decrementado a ${this.count}`)
      }
    },
    addFive() {
      const oldCount = this.count
      this.count = Math.min(this.count + 5, 100)
      this.incrementCount++
      this.totalClicks++
      this.addToHistory('increment', `+5: ${oldCount} → ${this.count}`)
    },
    subtractFive() {
      const oldCount = this.count
      this.count = Math.max(this.count - 5, 0)
      this.decrementCount++
      this.totalClicks++
      this.addToHistory('decrement', `-5: ${oldCount} → ${this.count}`)
    },
    reset() {
      const oldCount = this.count
      this.count = 0
      this.resetCount++
      this.totalClicks++
      this.addToHistory('reset', `Reset desde ${oldCount} a 0`)
    },
    addToHistory(type, description) {
      this.history.push({
        type,
        description,
        time: new Date().toLocaleTimeString()
      })
      
      // Keep only last 10 actions
      if (this.history.length > 10) {
        this.history = this.history.slice(-10)
      }
    }
  },
  mounted() {
    this.addToHistory('system', 'Contador inicializado')
  }
}
</script>

<style scoped>
.counter-container {
  padding: 2rem;
  text-align: center;
}

.counter-display {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 3rem 2rem;
  border-radius: 20px;
  margin-bottom: 2rem;
  box-shadow: 0 15px 35px rgba(102, 126, 234, 0.3);
}

.counter-number {
  font-size: 4rem;
  font-weight: bold;
  line-height: 1;
  margin-bottom: 0.5rem;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
}

.counter-label {
  font-size: 1.2rem;
  opacity: 0.9;
  text-transform: uppercase;
  letter-spacing: 2px;
}

.controls-section {
  margin-bottom: 2rem;
}

.primary-controls {
  display: flex;
  justify-content: center;
  gap: 1rem;
  margin-bottom: 1rem;
}

.secondary-controls {
  display: flex;
  justify-content: center;
  gap: 0.5rem;
}

.btn {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 1rem 2rem;
  font-size: 1rem;
  font-weight: bold;
  border: none;
  border-radius: 25px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
}

.btn:active:not(:disabled) {
  transform: translateY(0);
}

.btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
}

.btn-primary {
  background: linear-gradient(45deg, #10b981, #059669);
  color: white;
}

.btn-secondary {
  background: linear-gradient(45deg, #6b7280, #4b5563);
  color: white;
}

.btn-success {
  background: linear-gradient(45deg, #3b82f6, #1d4ed8);
  color: white;
  padding: 0.75rem 1rem;
}

.btn-warning {
  background: linear-gradient(45deg, #f59e0b, #d97706);
  color: white;
  padding: 0.75rem 1rem;
}

.btn-danger {
  background: linear-gradient(45deg, #ef4444, #dc2626);
  color: white;
  padding: 0.75rem 1rem;
}

.btn-icon {
  font-size: 1.2rem;
}

.status-section {
  margin-bottom: 2rem;
  min-height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stats-section {
  margin-bottom: 2rem;
  background: #f8fafc;
  padding: 1.5rem;
  border-radius: 15px;
  border: 1px solid #e2e8f0;
}

.stats-section h4 {
  margin-bottom: 1rem;
  color: #1e293b;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: 1rem;
}

.stat-item {
  background: white;
  padding: 1rem;
  border-radius: 10px;
  text-align: center;
  border: 1px solid #e2e8f0;
}

.stat-value {
  display: block;
  font-size: 1.8rem;
  font-weight: bold;
  color: #667eea;
  margin-bottom: 0.25rem;
}

.stat-label {
  font-size: 0.8rem;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.progress-section {
  margin-bottom: 2rem;
}

.progress-label {
  font-weight: 600;
  margin-bottom: 0.5rem;
  color: #374151;
}

.progress-bar {
  width: 100%;
  height: 20px;
  background: #e5e7eb;
  border-radius: 10px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  border-radius: 10px;
  transition: width 0.5s ease, background-color 0.3s ease;
}

.progress-fill.low {
  background: linear-gradient(90deg, #ef4444, #f87171);
}

.progress-fill.medium {
  background: linear-gradient(90deg, #f59e0b, #fbbf24);
}

.progress-fill.high {
  background: linear-gradient(90deg, #3b82f6, #60a5fa);
}

.progress-fill.complete {
  background: linear-gradient(90deg, #10b981, #34d399);
}

.history-section {
  background: #f1f5f9;
  padding: 1.5rem;
  border-radius: 15px;
  border: 1px solid #cbd5e1;
  text-align: left;
}

.history-section h4 {
  margin-bottom: 1rem;
  color: #1e293b;
}

.history-list {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.history-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem;
  background: white;
  border-radius: 8px;
  border-left: 4px solid;
}

.history-item.increment {
  border-left-color: #10b981;
}

.history-item.decrement {
  border-left-color: #f59e0b;
}

.history-item.reset {
  border-left-color: #ef4444;
}

.history-item.system {
  border-left-color: #6b7280;
}

.history-action {
  font-weight: 500;
  color: #374151;
}

.history-time {
  font-size: 0.85rem;
  color: #6b7280;
}

@media (max-width: 768px) {
  .counter-number {
    font-size: 3rem;
  }
  
  .primary-controls {
    flex-direction: column;
    align-items: center;
  }
  
  .secondary-controls {
    flex-wrap: wrap;
  }
  
  .stats-grid {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .btn {
    padding: 0.75rem 1.5rem;
    font-size: 0.9rem;
  }
}</style>