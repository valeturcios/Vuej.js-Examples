<template>
  <div class="conditional-render-container">
    <!-- Control Section -->
    <div class="control-section">
      <button @click="changeCondition" class="btn btn-primary">
        🎲 Cambiar Condición
      </button>
      
      <div class="condition-info">
        <span class="condition-label">Estado Actual:</span>
        <span class="condition-value" :class="condition">
          {{ conditionLabels[condition] }}
        </span>
      </div>
    </div>

    <!-- Main Conditional Content -->
    <div class="content-section">
      <transition name="slide" mode="out-in">
        <div v-if="condition === 'success'" key="success" class="message success">
          <div class="message-header">
            <span class="message-icon">✅</span>
            <h3>¡Éxito Completo!</h3>
          </div>
          <div class="message-body">
            <p>Todo está funcionando perfectamente. El sistema está operativo al 100%.</p>
            <div class="success-details">
              <div class="detail-item">
                <span class="detail-icon">🚀</span>
                <span>Rendimiento óptimo</span>
              </div>
              <div class="detail-item">
                <span class="detail-icon">✨</span>
                <span>Sin errores detectados</span>
              </div>
              <div class="detail-item">
                <span class="detail-icon">🎯</span>
                <span>Todos los objetivos cumplidos</span>
              </div>
            </div>
          </div>
        </div>

        <div v-else-if="condition === 'warning'" key="warning" class="message warning">
          <div class="message-header">
            <span class="message-icon">⚠️</span>
            <h3>Atención Requerida</h3>
          </div>
          <div class="message-body">
            <p>Se han detectado algunas situaciones que requieren tu atención.</p>
            <div class="warning-list">
              <div class="warning-item">
                <span class="warning-bullet">⚡</span>
                <span>Revisar la configuración de red</span>
              </div>
              <div class="warning-item">
                <span class="warning-bullet">📊</span>
                <span>Uso de memoria por encima del 75%</span>
              </div>
              <div class="warning-item">
                <span class="warning-bullet">🔄</span>
                <span>Actualizaciones pendientes disponibles</span>
              </div>
            </div>
          </div>
        </div>

        <div v-else key="error" class="message error">
          <div class="message-header">
            <span class="message-icon">❌</span>
            <h3>Error Crítico</h3>
          </div>
          <div class="message-body">
            <p>Se ha producido un error crítico que requiere intervención inmediata.</p>
            <div class="error-details">
              <div class="error-code">
                <span class="code-label">Código de Error:</span>
                <span class="code-value">{{ errorCode }}</span>
              </div>
              <div class="error-actions">
                <button @click="simulateRestart" class="btn btn-danger btn-small">
                  🔄 Reintentar
                </button>
                <button @click="showErrorLog" class="btn btn-secondary btn-small">
                  📋 Ver Log
                </button>
              </div>
            </div>
          </div>
        </div>
      </transition>
    </div>

    <!-- Statistics Section -->
    <div class="stats-section">
      <h4>📊 Estadísticas de Estados</h4>
      <div class="stats-grid">
        <div class="stat-item success">
          <span class="stat-number">{{ stateCount.success }}</span>
          <span class="stat-label">Éxitos</span>
          <div class="stat-bar">
            <div class="stat-fill" :style="{ width: successPercentage + '%' }"></div>
          </div>
        </div>
        
        <div class="stat-item warning">
          <span class="stat-number">{{ stateCount.warning }}</span>
          <span class="stat-label">Advertencias</span>
          <div class="stat-bar">
            <div class="stat-fill" :style="{ width: warningPercentage + '%' }"></div>
          </div>
        </div>
        
        <div class="stat-item error">
          <span class="stat-number">{{ stateCount.error }}</span>
          <span class="stat-label">Errores</span>
          <div class="stat-bar">
            <div class="stat-fill" :style="{ width: errorPercentage + '%' }"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- History Timeline -->
    <div class="timeline-section">
      <h4>📈 Historial de Estados</h4>
      <div class="timeline">
        <div 
          v-for="(entry, index) in stateHistory.slice(-6)" 
          :key="index"
          class="timeline-item"
          :class="entry.state"
        >
          <div class="timeline-marker"></div>
          <div class="timeline-content">
            <div class="timeline-header">
              <span class="timeline-state">{{ conditionLabels[entry.state] }}</span>
              <span class="timeline-time">{{ entry.time }}</span>
            </div>
            <div class="timeline-description">{{ entry.description }}</div>
          </div>
        </div>
      </div>
    </div>

    <!-- System Status Panel -->
    <div class="status-panel" :class="condition">
      <div class="panel-header">
        <span class="panel-title">🖥️ Estado del Sistema</span>
        <span class="panel-indicator" :class="condition"></span>
      </div>
      
      <div class="panel-metrics">
        <div class="metric">
          <span class="metric-label">Tiempo activo:</span>
          <span class="metric-value">{{ uptime }}</span>
        </div>
        <div class="metric">
          <span class="metric-label">Cambios totales:</span>
          <span class="metric-value">{{ totalChanges }}</span>
        </div>
        <div class="metric">
          <span class="metric-label">Estado actual:</span>
          <span class="metric-value">{{ conditionLabels[condition] }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ConditionalRender',
  data() {
    return {
      condition: 'success',
      stateCount: {
        success: 1,
        warning: 0,
        error: 0
      },
      stateHistory: [],
      startTime: Date.now(),
      totalChanges: 0,
      conditionLabels: {
        success: 'Funcionando Correctamente',
        warning: 'Requiere Atención',
        error: 'Error Crítico'
      },
      errorCodes: ['ERR_001', 'ERR_404', 'ERR_500', 'ERR_503', 'ERR_TIMEOUT']
    }
  },
  computed: {
    totalStates() {
      return this.stateCount.success + this.stateCount.warning + this.stateCount.error
    },
    successPercentage() {
      return this.totalStates ? (this.stateCount.success / this.totalStates) * 100 : 0
    },
    warningPercentage() {
      return this.totalStates ? (this.stateCount.warning / this.totalStates) * 100 : 0
    },
    errorPercentage() {
      return this.totalStates ? (this.stateCount.error / this.totalStates) * 100 : 0
    },
    uptime() {
      const minutes = Math.floor((Date.now() - this.startTime) / 60000)
      const seconds = Math.floor(((Date.now() - this.startTime) % 60000) / 1000)
      return `${minutes}m ${seconds}s`
    },
    errorCode() {
      return this.errorCodes[Math.floor(Math.random() * this.errorCodes.length)]
    }
  },
  methods: {
    changeCondition() {
      const conditions = ['success', 'warning', 'error']
      const currentIndex = conditions.indexOf(this.condition)
      const nextIndex = (currentIndex + 1) % conditions.length
      
      this.condition = conditions[nextIndex]
      this.stateCount[this.condition]++
      this.totalChanges++
      
      // Add to history
      this.stateHistory.push({
        state: this.condition,
        time: new Date().toLocaleTimeString(),
        description: this.getStateDescription(this.condition)
      })
      
      // Keep only last 20 entries
      if (this.stateHistory.length > 20) {
        this.stateHistory = this.stateHistory.slice(-20)
      }
    },
    getStateDescription(state) {
      const descriptions = {
        success: 'Sistema funcionando sin problemas',
        warning: 'Se detectaron advertencias del sistema',
        error: 'Error crítico en el sistema'
      }
      return descriptions[state]
    },
    simulateRestart() {
      alert('🔄 Reiniciando sistema...')
      setTimeout(() => {
        this.condition = 'success'
        this.stateCount.success++
        this.totalChanges++
        
        this.stateHistory.push({
          state: 'success',
          time: new Date().toLocaleTimeString(),
          description: 'Sistema reiniciado exitosamente'
        })
        
        alert('✅ Sistema reiniciado exitosamente')
      }, 2000)
    },
    showErrorLog() {
      const errorLog = `
=== LOG DE ERRORES ===
Timestamp: ${new Date().toISOString()}
Error Code: ${this.errorCode}
Descripción: Error simulado para demostración
Stack Trace: SimulatedError at ConditionalRender.vue:line:42
Status: CRÍTICO
      `
      alert(errorLog)
    }
  },
  mounted() {
    // Initialize first history entry
    this.stateHistory.push({
      state: this.condition,
      time: new Date().toLocaleTimeString(),
      description: 'Sistema inicializado correctamente'
    })
    
    // Update uptime every second
    setInterval(() => {
      this.$forceUpdate()
    }, 1000)
  }
}
</script>

<style scoped>
.conditional-render-container {
  padding: 2rem;
}

.control-section {
  display: flex;
  align-items: center;
  gap: 2rem;
  margin-bottom: 2rem;
  padding: 1.5rem;
  background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
  border-radius: 15px;
}

.condition-info {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.condition-label {
  font-weight: 600;
  color: #374151;
}

.condition-value {
  padding: 0.5rem 1rem;
  border-radius: 20px;
  font-weight: bold;
  font-size: 0.9rem;
}

.condition-value.success {
  background: #d1fae5;
  color: #065f46;
}

.condition-value.warning {
  background: #fef3c7;
  color: #92400e;
}

.condition-value.error {
  background: #fee2e2;
  color: #991b1b;
}

.content-section {
  margin-bottom: 3rem;
  min-height: 300px;
}

.message {
  padding: 2rem;
  border-radius: 15px;
  border: 2px solid;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

.message.success {
  background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
  border-color: #10b981;
}

.message.warning {
  background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
  border-color: #f59e0b;
}

.message.error {
  background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
  border-color: #ef4444;
}

.message-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 1.5rem;
}

.message-icon {
  font-size: 2rem;
}

.message-header h3 {
  margin: 0;
  font-size: 1.5rem;
}

.message-body p {
  font-size: 1.1rem;
  margin-bottom: 1.5rem;
  line-height: 1.6;
}

.success-details {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.detail-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0.75rem;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 10px;
}

.detail-icon {
  font-size: 1.3rem;
}

.warning-list {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.warning-item {
  display: flex;
  align-items: center;
  gap: 1rem;
  padding: 0.75rem;
  background: rgba(255, 255, 255, 0.6);
  border-radius: 8px;
  border-left: 4px solid #f59e0b;
}

.warning-bullet {
  font-size: 1.2rem;
}

.error-details {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.error-code {
  padding: 1rem;
  background: rgba(255, 255, 255, 0.7);
  border-radius: 10px;
  border: 1px solid #ef4444;
}

.code-label {
  font-weight: 600;
  color: #991b1b;
  margin-right: 1rem;
}

.code-value {
  font-family: monospace;
  font-size: 1.1rem;
  font-weight: bold;
  color: #dc2626;
}

.error-actions {
  display: flex;
  gap: 1rem;
}

.btn-small {
  padding: 0.5rem 1rem;
  font-size: 0.9rem;
}

.stats-section {
  margin-bottom: 2rem;
  background: #f1f5f9;
  padding: 2rem;
  border-radius: 15px;
  border: 1px solid #cbd5e1;
}

.stats-section h4 {
  margin-bottom: 1.5rem;
  color: #1e293b;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1.5rem;
}

.stat-item {
  background: white;
  padding: 1.5rem;
  border-radius: 12px;
  text-align: center;
  border: 2px solid;
  position: relative;
  overflow: hidden;
}

.stat-item.success {
  border-color: #10b981;
}

.stat-item.warning {
  border-color: #f59e0b;
}

.stat-item.error {
  border-color: #ef4444;
}

.stat-number {
  display: block;
  font-size: 2.5rem;
  font-weight: bold;
  margin-bottom: 0.5rem;
}

.stat-item.success .stat-number {
  color: #10b981;
}

.stat-item.warning .stat-number {
  color: #f59e0b;
}

.stat-item.error .stat-number {
  color: #ef4444;
}

.stat-label {
  font-weight: 600;
  color: #374151;
  text-transform: uppercase;
  font-size: 0.9rem;
  letter-spacing: 1px;
}

.stat-bar {
  width: 100%;
  height: 6px;
  background: #e5e7eb;
  border-radius: 3px;
  margin-top: 1rem;
  overflow: hidden;
}

.stat-fill {
  height: 100%;
  border-radius: 3px;
  transition: width 0.8s ease;
}

.stat-item.success .stat-fill {
  background: #10b981;
}

.stat-item.warning .stat-fill {
  background: #f59e0b;
}

.stat-item.error .stat-fill {
  background: #ef4444;
}

.timeline-section {
  margin-bottom: 2rem;
  background: #fafafa;
  padding: 2rem;
  border-radius: 15px;
  border: 1px solid #e5e7eb;
}

.timeline-section h4 {
  margin-bottom: 1.5rem;
  color: #374151;
}

.timeline {
  position: relative;
  padding-left: 2rem;
}

.timeline::before {
  content: '';
  position: absolute;
  left: 10px;
  top: 0;
  bottom: 0;
  width: 2px;
  background: #d1d5db;
}

.timeline-item {
  position: relative;
  margin-bottom: 1.5rem;
}

.timeline-marker {
  position: absolute;
  left: -1.5rem;
  top: 0.5rem;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: 2px solid white;
  box-shadow: 0 0 0 2px;
}

.timeline-item.success .timeline-marker {
  background: #10b981;
  box-shadow: 0 0 0 2px #10b981;
}

.timeline-item.warning .timeline-marker {
  background: #f59e0b;
  box-shadow: 0 0 0 2px #f59e0b;
}

.timeline-item.error .timeline-marker {
  background: #ef4444;
  box-shadow: 0 0 0 2px #ef4444;
}

.timeline-content {
  background: white;
  padding: 1rem;
  border-radius: 10px;
  border: 1px solid #e5e7eb;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.timeline-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
}

.timeline-state {
  font-weight: 600;
  color: #374151;
}

.timeline-time {
  font-size: 0.85rem;
  color: #6b7280;
}

.timeline-description {
  color: #6b7280;
  font-size: 0.9rem;
}

.status-panel {
  padding: 1.5rem;
  border-radius: 15px;
  border: 2px solid;
  background: white;
}

.status-panel.success {
  border-color: #10b981;
  background: linear-gradient(135deg, #ffffff 0%, #f0fdf4 100%);
}

.status-panel.warning {
  border-color: #f59e0b;
  background: linear-gradient(135deg, #ffffff 0%, #fffbeb 100%);
}

.status-panel.error {
  border-color: #ef4444;
  background: linear-gradient(135deg, #ffffff 0%, #fef2f2 100%);
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid #e5e7eb;
}

.panel-title {
  font-size: 1.2rem;
  font-weight: 600;
  color: #374151;
}

.panel-indicator {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  animation: pulse 2s infinite;
}

.panel-indicator.success {
  background: #10b981;
  box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.3);
}

.panel-indicator.warning {
  background: #f59e0b;
  box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.3);
}

.panel-indicator.error {
  background: #ef4444;
  box-shadow: 0 0 0 4px rgba(239, 68, 68, 0.3);
}

@keyframes pulse {
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}

.panel-metrics {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.metric {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.75rem;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 8px;
  border: 1px solid #e5e7eb;
}

.metric-label {
  font-weight: 500;
  color: #6b7280;
}

.metric-value {
  font-weight: 600;
  color: #374151;
}

.slide-enter-active, .slide-leave-active {
  transition: all 0.5s ease;
}

.slide-enter-from {
  opacity: 0;
  transform: translateY(30px);
}

.slide-leave-to {
  opacity: 0;
  transform: translateY(-30px);
}

@media (max-width: 768px) {
  .control-section {
    flex-direction: column;
    gap: 1rem;
  }
  
  .stats-grid {
    grid-template-columns: 1fr;
  }
  
  .panel-metrics {
    grid-template-columns: 1fr;
  }
  
  .error-actions {
    flex-direction: column;
  }
  
  .timeline-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 0.5rem;
  }
}
</style>